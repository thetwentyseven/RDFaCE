<?php
// Textrazor PHP API - https://www.textrazor.com/docs/php
require_once CONTEXTO_PLUGIN_DIR . '/public/js/tinymce/plugins/contexto/textrazor/contexto.php';

// TODO:We must put the require here not in example.php


?>
